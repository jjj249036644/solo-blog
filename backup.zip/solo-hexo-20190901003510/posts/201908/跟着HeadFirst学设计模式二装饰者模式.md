title: '跟着Head First学设计模式(二) -- 装饰者模式 '
date: '2019-08-31 21:50:31'
updated: '2019-08-31 21:51:12'
tags: [设计模式]
permalink: /articles/2019/08/31/1567259431718.html
---
![](https://img.hacpai.com/bing/20180511.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# 装饰者模式

干着干着,你发现开一家咖啡店也蛮不错,于是,你就着手开始准备开店,万万没想到,你的咖啡店居然以十分夸张的扩张速度,开了数百家连锁店,厉害!但是因为扩张速度实在太快了,原先的订单系统的弊端就显现出来了,原先的设计如下:
![图片1.png](https://img.hacpai.com/file/2019/08/图片1-311d3d13.png)

在购买咖啡时,也可以要求向其中加入各种饮料,比如蒸奶(Steame Milk),豆浆(Soy),摩卡(mocha),或覆盖奶泡,咖啡店会根据加入的调料不同,收取不同的费用,所以订单系统也需要将这个情况考虑进去,于是就有了:
![图片1.png](https://img.hacpai.com/file/2019/08/图片1-071e2c09.png)


你也可以发现,真的是爆炸,如果牛奶的价格上调,你是不是需要修改所有和牛奶相关的类的价格?很明显,这违背了”针对接口编程,不针对实现编程”和”多用组合,少用继承”者两个设计原则,造成了这个订单系统的维护噩梦,这很严重.

---

好了,我们已经了解到了利用继承无法完全解决问题,所以,在这里我们要采用不一样的做法,我们要以饮料为主体,用调料来装饰它.例如:顾客想要摩卡和奶泡深培咖啡,那么我们需要做的是:
1.拿一个深培咖啡对象
2.用摩卡对象装饰它
3.用奶泡对象装饰它
4.调用cost方法,并依赖委托得出总的价格

最终得到一个组合对象:
![图片1.png](https://img.hacpai.com/file/2019/08/图片1-b32795bf.png)


从上我们可以知道的是:
* 装饰者和被装饰者对象有想用的超类型
* 你可以用一个或多个装饰者包装一个对象
* 既然装饰者和被装饰对象有相同的超类型,所以在任何需要原始对象(被包装的)的场合们可以用装饰过的对象代替他
* 装饰者可以在所委托被装饰者的行为之前或之后,加上自己的行为,以达到目的
* 对象可以在任何时候被装饰,所以可以在运行时动态地,不限量地用你喜欢的装饰者来装饰对象

现在,我们来看看装饰者模式的定义:**装饰者模式动态地将责任附加到对象上,若要扩展功能,装饰这提供了比继承更有弹性的替代方案**

那我们就根据上述条件开始构建系统,大致的类图便出来了:


我们开始写饮料的基类:Beverage
```
/**
 * 饮料基类
 */
public abstract class Beverage {
    String description = "Unknown Beverage";

    public String getDescription(){
        return description;
    }

    public abstract double cost();
}
```

根据第一条,编写调料的基类,CondimentDecorator
/**
 * 调料类
 */
public abstract class CondimentDecorator extends Beverage {
    public abstract String getDecription();
}

开始编写深培咖啡的类:DarkRoast
```
public class DarkRoast extends Beverage {
    @Override
    public double cost() {
        //咖啡的价格
        return 2.59;
    }

    public DarkRoast() {
        //将描述修改为咖啡名称
        description = "DarkRoast";
    }
}
```

类似就会有Espresso和HouseBlend咖啡

开始编写调料类Mocha
```
public class Mocha extends CondimentDecorator {
    //饮料,也就是被装饰者
    private Beverage bevarage;

    public Mocha(Beverage beverage) {
        //通过构造函数,将基础饮料赋值,也就是知道了该调味料到底需要加到哪杯饮料中
        this.bevarage = beverage;
        //将饮料的描述后添加是哪种调料
        description = bevarage.getDescription() + ", Mocha";
    }

    @Override
    public String getDecription() {
        return bevarage.getDescription() + ", Mocha";
    }

    @Override
    public double cost() {
        return 0.2 + bevarage.cost();
    }
}
```
同样也会有调料Milk和Soy
PS:

| 名称| 价格|
| --- | --- |
| DarkRoast	| 2.59元|
| Espresso 	| 1.99元 | 
| HouseBlend 	| 0.89元 |
| Mocha 		| 0.2元  |
| Milk		| 0.11元|
| Soy 		| 0.33元 |


写完了,我们来试试新的订单系统吧~

public class OrderSystemTest {

    public static void main(String[] args) {
        //用户点了一杯深培咖啡,加牛奶和摩卡
        Beverage darkRoast = new DarkRoast();
        //用牛奶装饰
        darkRoast = new Milk(darkRoast);
        //用摩卡装饰
        darkRoast = new Mocha(darkRoast);
        System.out.println("咖啡内容是:" + darkRoast.getDescription() + ",最终一共花费了:" + darkRoast.cost() + "元");

        //用户点了一杯浓缩咖啡,加了牛奶和豆浆
        Beverage espresso = new Espresso();
        //用牛奶装饰
        espresso = new Milk(espresso);
        //用豆浆装饰
        espresso = new Soy(espresso);
        System.out.println("咖啡内容是:" + espresso.getDescription() + ",最终一共花费了:" + espresso.cost() + "元");

        //用户点了一杯HouseBlend,加了牛奶,摩卡,豆浆
        Beverage houseBlend = new HouseBlend();
        //用牛奶装饰
        houseBlend = new Milk(houseBlend);
        //用摩卡装饰
        houseBlend = new Mocha(houseBlend);
        //用豆浆装饰
        houseBlend = new Soy(houseBlend);
        System.out.println("咖啡内容是:" + houseBlend.getDescription() + ",最终一共花费了:" + houseBlend.cost() + "元");
    }
}

运行结果:
![图片1.png](https://img.hacpai.com/file/2019/08/图片1-36549d9a.png)


我们可以看到,客户点的咖啡订单被成功创建,价格也能正确计算,我们的装饰者就完成啦

我们来看看这次的要点
1. 继承属于扩展形式之一,但不见得是达到弹性设计的最佳方案
2. 在我们的设计中,应该允许行为可以被扩展,而无需修改现有的代码
3. 组合和委托可用于在运行时动态地加上新的行为
4. 除了继承,装饰者模式也可以让我们扩展行为
5. 装饰者模式意味着一群装饰者类,这些类用来包装具体组件
6. 装饰者类范引出被装饰的组件类型(事实上,他们具有相同的类型,都经过接口或继承实现)
7. 装饰者可以在被装饰者的行为前面或后面加上自己的行为,升值将被装饰者的行为整个取代掉,而达到特定的目的
8. 你可以用无数个装饰者包装一个组件
9. 装饰者一般对组件的客户是透明的,除非客户程序依赖于组件的具体类型
10. 装饰者会导致设计中出现许多小对象,如果过度使用,会让程序变得很复杂
