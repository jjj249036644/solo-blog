title: 跟着Head First学设计模式(一) -- 观察者模式
date: '2019-08-30 23:58:34'
updated: '2019-08-31 00:05:38'
tags: [设计模式]
permalink: /articles/2019/08/30/1567180714315.html
---
# 跟着Head First学设计模式

	假设你是一家气象公司的业务经理,公司下有湿度,温度,气压感应装置,现在有公司向你们购买产品.需要你们在湿度,温度,气压改变时,实时将改变的数据通知到他们.

	此系统中有三个部分,分别是气象站(实时获取气象数据的物理装置),WeatherData(追踪来自气象站的数据,并实时更新布告板)和布告板(显示当前天气情况给用户看),那我们现在的架构就是:
![图片1.png](https://img.hacpai.com/file/2019/08/图片1-0c8462df.png)



观察者模式:**定义了一个对象之间的一对多依赖,这样一来,当一个对象改变状态时,他的所有依赖着都会受到通知并自动更新**

#### 观察者模式的目的是什么呢?
观察者模式提供了一种对象设计,让主题和观察者之间松耦合.

#### 但为什么会有松耦合的效果呢?
	对于观察者的一切,主题只知道观察者实现了某个接口(也就是Observer接口),主题不需要知道观察者的具体类是谁,具体做了什么事,对于主题,只需要知道他是Observer类型就可以,这就是Java多态的魅力了,Observer类型的引用在运行过程中动态地绑定Observer的实现类.
	在任何时候,我们都可以新增或删除观察者,这并不会影响到主题的正常运行,因	为注意唯一依赖的是观察者列表(里面存放的是每个订阅这个主题的观察者),但具体的观察者的不同实现无需关心,所以我们能随时随地地增加或移除观察者.
	换句话说,如果来了一个新的观察者类型,我们无需为了兼容新的观察者类型而去修改主题类的代码,我们要做的只是需要在新的类中,实现观察者接口,然后向主题注册成为观察者即可.
	改变主题或者观察者其中一方,并不会影响另一方的正常运行,这就是简单理解的松耦合,在观察者模式中,我们可以轻易地复用任何一方,因此观察者模式是一种松耦合设计

这边也是设计模式的一个目的:**为了交互对象之间的松耦合设计而努力.**

松耦合设计之所以能让我们建立弹性的OO系统,能应对变化,是因为对象之间的互相依赖程度降到了最低.


现在我们回到气象站项目,每个公司的数据都是通过订阅气象站,气象站主动发送的方式获得的,这样的情况是十分符合观察者模式的来解决

观察者模式必要的有两个接口,分别是Subject和Observer
Subject,主题,主要的作用就是提供订阅,取消订阅,通知所有订阅者的功能
Observer,观察者,主要作用就是自己获取到主题传过来的数据,进行各自的处理
因此就有了一下两个接口
```
public interface Subject {
    /**
     * 注册观察者
     * @param observer
     */
    public void registerObserver(Observer observer);

    /**
     * 删除观察者
     * @param observer
     */
    public void removeObserver(Observer observer);

    /**
     * 当主题状态改变时,这个方法会被调用,用来通知所有的观察者
     */
    public void notifyObservers();
}
```

```
public interface Observer {

    /**
     * 当气象局的观测值发生改变时,会调用该方法,并传递这三个值
     * 所有的观察者都需要实现这个方法
     * @param temp  温度
     * @param humidity  湿度
     * @param pressure  气压
     */
    public void update(float temp,float humidity,float pressure);
}
```


布告板,因为都是用来显示的,为了统一规范,也抽取成了一个接口DisplayElement
```
/**
 * 布告板,用来显示三个数据
 */
public interface DisplayElement {
    public void display();
}
```


构建气象数据收集器类WeatherData
气象数据收集器是传递数据的,因此很容易就能想到是需要实现Subject接口的
```
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * 气象站类
 * 获取气象信息,并更新用户气象的类
 */
public class WeatherData implements Subject{
    private List<Observer> observers;
    private float temp;
    private float humidity;
    private float pressure;

    public WeatherData() {
        observers = new ArrayList<Observer>();
    }

    /**
     * 注册观察者
     * @param observer
     */
    public void registerObserver(Observer observer) {
        observers.add(observer);
    }

    /**
     * 移除观察者
     * @param observer
     */
    public void removeObserver(Observer observer) {
        Iterator<Observer> iterator = observers.iterator();
        while (iterator.hasNext()) {
            Observer next = iterator.next();
            if (next.equals(observer)) {
                iterator.remove();
                break;
            }
        }
    }

    /**
     * 通知所有的观察者,调用所有的观察者的update方法
     */
    public void notifyObservers() {
        for (Observer observer : observers) {
            observer.update(temp,humidity,pressure);
        }
    }

    /**
     * 当测量结果发生改变时
     * @param temp
     * @param humidity
     * @param pressure
     */
    public void measureMentsChanged(float temp,float humidity,float pressure){
        this.temp = temp;
        this.humidity = humidity;
        this.pressure = pressure;
        System.out.println("----------当前时间是" + System.currentTimeMillis());
        notifyObservers();
        System.out.println();
    }
}
```




有了气象数据收集器,就需要有不同公司的布告板设备,在模式中,充当观察者的角色
CurrentCondition公司的布告板:
```
public class CurrentConditionDisplay implements Observer, DisplayElement {
    private float temp;
    private float humidity;
    private float pressure;

    private Subject weatherData;

    /**
     * 通过构造方法初始化气象站,并向气象站将自己注册成功观察者
     * @param weatherData
     */
    public CurrentConditionDisplay(Subject weatherData) {
        this.weatherData = weatherData;
        weatherData.registerObserver(this);
    }

    public void display() {
        System.out.println("CurrentCondition公司的显示器播报当前气候变化,当前气温是:" + temp + "摄氏度,当前湿度是" + humidity + "%,当前气压是" + pressure + "帕");
    }

    public void update(float temp, float humidity, float pressure) {
        this.temp = temp;
        this.humidity = humidity;
        this.pressure = pressure;
        display();
    }
}
```

Statistics公司的布告板
```
public class StatisticsDisplay implements Observer,DisplayElement {

    private float temp;
    private float humidity;
    private float pressure;

    private Subject weatherData;

    /**
     * 通过构造方法初始化气象站,并向气象站将自己注册成功观察者
     * @param weatherData
     */
    public StatisticsDisplay(Subject weatherData) {
        this.weatherData = weatherData;
        weatherData.registerObserver(this);
    }

    public void display() {
        System.out.print("Statistics公司的显示器播报当前气候变化,当前气温是:" + temp + "摄氏度,当前湿度是" + humidity + "%,当前气压是" + pressure + "帕;");
        System.out.println("体感温度,随便写的,三者乘积" + temp*humidity*pressure );
    }

    public void update(float temp, float humidity, float pressure) {
        this.temp = temp;
        this.humidity = humidity;
        this.pressure = pressure;
        display();
    }
}
```

Forecast的布告板
```
public class ForecastDisplay implements Observer,DisplayElement {

    private float temp;
    private float humidity;

    private Subject weatherData;

    /**
     * 通过构造方法初始化气象站,并向气象站将自己注册成功观察者
     * @param weatherData
     */
    public ForecastDisplay(Subject weatherData) {
        this.weatherData = weatherData;
        weatherData.registerObserver(this);
    }

    public void display() {
        System.out.println("Forecast公司的显示器播报当前气候变化,当前气温是:" + temp + "摄氏度,当前湿度是" + humidity + "%");
    }

    public void update(float temp, float humidity, float pressure) {
        this.temp = temp;
        this.humidity = humidity;
        display();
    }
}
```

不同公司需要的数据个数以及各自的数据处理都不相同,因此我们可以知道,Observer是相互独立的,互不影响的每个公司只关注各自的公司的业务.

好了,我们可以正式开始测试效果,来先写一个气象站来测试一下效果
```
public class WeatherStation {
    public static void main(String[] args) throws InterruptedException {
        //构建一个新的气象数据收集器
        WeatherData weatherData = new WeatherData();
        //CurrentCondition公司接入气象站
        CurrentConditionDisplay currentConditionDisplay = new CurrentConditionDisplay(weatherData);
        //Statistics公司接入气象站
        StatisticsDisplay statisticsDisplay = new StatisticsDisplay(weatherData);
        //气象数据收集器第一次收集到数据
        weatherData.measureMentsChanged(35,20,1000);
        Thread.sleep(1111);
        //Forecast公司接入气象站
        ForecastDisplay forecastDisplay = new ForecastDisplay(weatherData);
        //气象数据收集器第二次收集到数据
        weatherData.measureMentsChanged(13,33,1001);
        Thread.sleep(1111);
        //气象数据收集器第三次收集到数据
        weatherData.measureMentsChanged(22,64,999);
    }
}
```


运行效果
![图片2.png](https://img.hacpai.com/file/2019/08/图片2-a334455e.png)


我们可以发现第一次Forecast公司并没有注册,因此,第一次是没有通知到Forecast公司,后面两次Forecast公司注册成为观察者后,气象站才通知到Forecast公司,到此,我们已经从无到有地完成了观察者模式,但是,Java API中有内置的观察者模式供我们使用,类java.util.Observable和接口java.util.Observer,那我们就再利用Java API的规范再实现一次气象站吧~

使用Java API实现观察者模式
类java.util.Observable与我们的Subject类似(Observable可观察的),接口java.util.Observer与我们的Observer类似,很多功能Java API已经帮我们事先准备好了,因此,我们可以很方便地使用这两个类来完成订阅,取消订阅的功能

气象数据收集器类:
```
import java.util.Observable;

/**
 * 气象数据收集器
 */
public class WeatherData extends Observable {

    private float temperature;
    private float humidity;
    private float pressure;

    public WeatherData(){}

    public void measureMentsChanged(){
        //数据修改时,需要修改被观察者的状态,内部会有一个change的boolean值,
        //在调用notifyObservers这个方法时,会判断是否为true,如果为false,这不去通知各个观察者
        //若成功通知观察者后,notifyObservers中会将change重置为false
        setChanged();
        notifyObservers();
    }

    /**
     * 搜集到新的数据时调用该方法
     * @param temperature
     * @param humidity
     * @param pressure
     */
    public void setMeasurements(float temperature,float humidity,float pressure){
        this.temperature = temperature;
        this.humidity = humidity;
        this.pressure = pressure;
        //调用通知各个观察者的方法
        measureMentsChanged();
    }

    public float getTemperature() {
        return temperature;
    }

    public void setTemperature(float temperature) {
        this.temperature = temperature;
    }

    public float getHumidity() {
        return humidity;
    }

    public void setHumidity(float humidity) {
        this.humidity = humidity;
    }

    public float getPressure() {
        return pressure;
    }

    public void setPressure(float pressure) {
        this.pressure = pressure;
    }
}
```



CurrentCondition公司的布告板
```
import com.demo.pattern.observer.DisplayElement;

import java.util.Observable;
import java.util.Observer;

public class CurrentConditionDisplay implements Observer, DisplayElement {

    private Observable observable;
    private float temperature;
    private float humidity;
    private float pressure;

    public CurrentConditionDisplay(Observable observable) {
        this.observable = observable;
        observable.addObserver(this);
    }

    @Override
    public void display() {
        System.out.println("CurrentCondition公司的显示器播报当前气候变化,当前气温是:" + temperature + "摄氏度,当前湿度是" + humidity + "%,当前气压是" + pressure + "帕");
    }

    @Override
    public void update(Observable o, Object arg) {
        if (o instanceof WeatherData) {
            WeatherData weatherData = (WeatherData) o;
            this.temperature = weatherData.getTemperature();
            this.humidity = weatherData.getHumidity();
            this.pressure = weatherData.getPressure();
            display();
        }
    }
}
```

同样我们有Forecast公司的布告板
```
import com.demo.pattern.observer.DisplayElement;

import java.util.Observable;
import java.util.Observer;

public class ForecastDisplay implements Observer, DisplayElement {
    private float temp;
    private float humidity;

    private Observable observable;

    public ForecastDisplay(Observable observable) {
        this.observable = observable;
        observable.addObserver(this);
    }

    @Override
    public void display() {
        System.out.println("Forecast公司的显示器播报当前气候变化,当前气温是:" + temp + "摄氏度,当前湿度是" + humidity + "%");
    }

    @Override
    public void update(Observable o, Object arg) {
        if (o instanceof WeatherData) {
            WeatherData weatherData = (WeatherData) o;
            this.temp = weatherData.getTemperature();
            this.humidity = weatherData.getHumidity();
            display();
        }
    }
}
```

让我们来建立新的气象站来进行测试吧
```
public class WeatherStation {
    public static void main(String[] args) throws InterruptedException {
        WeatherData weatherData = new WeatherData();
        CurrentConditionDisplay currentConditionDisplay = new CurrentConditionDisplay(weatherData);
        //气象数据收集器第一次收集到数据
        weatherData.setMeasurements(35,20,1000);
        Thread.sleep(1111);
        //Forecast公司接入气象站
        ForecastDisplay setMeasurements = new ForecastDisplay(weatherData);
        //气象数据收集器第二次收集到数据
        weatherData.setMeasurements(13,33,1001);
        Thread.sleep(1111);
        //气象数据收集器第三次收集到数据
        weatherData.setMeasurements(22,64,999);
    }
}
```

运行结果:
![图片1.png](https://img.hacpai.com/file/2019/08/图片1-62ff5223.png)


完美~

不过,你是否注意到Observable是一个类,而不是接口,更糟糕的是,它甚至没有实现一个接口,违背了”多用组合,少用继承” 的设计原则,很大程度限制了它的使用和复用,但这并不代表它没有提供有用的功能

如果扩展Observable更符合你的需求,那么你就尽情地使用吧,否则,你可能需要使用我们第一种自己实现的这一套观察者模式,不过,不管用那种方法,原理是一样的,我们要善于利用,扬长避短~

来到尾巴了,我们来总结一下观察者模式的要点~
* 观察者模式定义了对象之间的一对多的关系
* 主题(也就是被观察者)用一个共同的接口来更新观察者
* 观察者和被观察者之间用松耦合的方式结合,被观察者不知道观察者的细节,只知道观察者实现了观察者接口
* 使用此模式时,你可以被观察者处推或拉数据
* 有多个观察者时,不可以依赖特定的通知次序
* Java中也提供了观察者模式的具体实现
* 需要注意java.util.Observable带来的一些问题
* 如果有必要的话,可以自己实现Observable
